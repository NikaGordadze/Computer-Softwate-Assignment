#ifndef ORDEREDINTSET_H
#define ORDEREDINTSET_H
#include "doubleLinkedList.h"
/**
 * @brief Ordered set structure.
 *
 * Stores a double linked list and the number
 * of elements in the set.
 */
typedef struct OrderedIntSet{
    DoubleLinkedList *list;
    int count;
}OrderedIntSet;
/**
 * @brief Creates an empty ordered set.
 *
 * Creates a new set with an empty
 * double linked list.
 * @return Pointer to the created set.
 */
OrderedIntSet *createOrderedSet(void);
/**
 * @brief Deletes an ordered set.
 *
 * Frees the list and the set memory.
 * @param set Pointer to the set.
 */
void deleteOrderedSet(OrderedIntSet *set);
#endif // ORDEREDINTSET_H
