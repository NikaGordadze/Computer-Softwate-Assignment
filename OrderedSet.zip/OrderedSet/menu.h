#ifndef MENU_H
#define MENU_H
#include <stdio.h>
#include "orderedIntSet.h"
/**
 * @brief Create a set in the array.
 *
 * Creates a new ordered set and stores it in the
 * selected position.
 * @param SetsArray Array of set pointers.
 */
void createSetOption(OrderedIntSet*SetsArray[],FILE *inputFile);
/**
 * @brief Deletes a set from array.
 *
 * Removes the set from the selected position in the array.
 * @param SetsArray Array of set pointers.
 */
void deleteSetOption(OrderedIntSet*SetsArray[],FILE *inputFile);
#endif // MENU_H